package ru.geekbrains.hwlesson1;

public class Fruit {
    float weight;

    public Fruit(float weight){
        this.weight = weight;
    }

    public float getWeight(){
        return weight;
    }
}
