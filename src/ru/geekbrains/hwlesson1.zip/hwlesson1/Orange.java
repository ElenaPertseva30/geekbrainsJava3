package ru.geekbrains.hwlesson1;

public class Orange extends Fruit {

    public Orange() {
        super(1.5f);
    }
}
