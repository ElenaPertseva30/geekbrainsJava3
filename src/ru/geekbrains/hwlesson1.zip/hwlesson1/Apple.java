package ru.geekbrains.hwlesson1;

public class Apple extends Fruit {

    public Apple() {
        super(1.0f);
    }
}
